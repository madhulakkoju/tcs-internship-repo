package com.backend.datavalidation;

public enum Validator {
	INTEGER,
	FLOAT,
	DOUBLE,
	EMAIL,
	DATE,
	MOBILE_IND,
	NAME,
}
