package com.backend.model;
public class Setup {
	  public static final String CLIENT_ID = "enter your app client id";
	  public static final String CLIENT_SECRET = "enter your app client secret";
	  public static final String REDIRECT_URL = "enter your app redirect url";
	}
