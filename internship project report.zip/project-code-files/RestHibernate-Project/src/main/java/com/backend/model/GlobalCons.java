package com.backend.model;

public class GlobalCons {
	   public static String AUTH = "auth";
	}
